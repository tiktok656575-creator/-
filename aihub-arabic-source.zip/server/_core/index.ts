import "dotenv/config";
import express from "express";
import { createServer } from "http";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { publicPlatformScript } from "./publicConfig";
import { invokeLLM, type Message } from "./llm";
import { appRouter } from "../routers";
import { createContext } from "./context";
import { serveStatic, setupVite } from "./vite";

async function startServer() {
  const app = express();
  const server = createServer(app);
  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));
  app.get("/api/health", (_req, res) => res.json({ status: "ok" }));
  app.get("/api/platform/config.js", (_req, res) => {
    res.set("Cache-Control", "no-store").type("application/javascript").send(publicPlatformScript());
  });
  app.post("/api/chat", async (req, res) => {
    const rawMessages = Array.isArray(req.body?.messages) ? req.body.messages : [];
    const model = typeof req.body?.model === "string" ? req.body.model : "auto";
    const tone = typeof req.body?.tone === "string" ? req.body.tone : "متوازن";
    const messages: Message[] = rawMessages
      .filter((message: unknown): message is { role: string; content: string } => {
        if (!message || typeof message !== "object") return false;
        const candidate = message as { role?: unknown; content?: unknown };
        return ["system", "user", "assistant"].includes(String(candidate.role)) && typeof candidate.content === "string";
      })
      .slice(-24)
      .map((message: { role: string; content: string }) => ({ role: message.role as Message["role"], content: message.content.slice(0, 30000) }));

    if (!messages.length || !messages.some(message => message.role === "user")) {
      return res.status(400).json({ error: "أرسل رسالة واحدة على الأقل للبدء." });
    }

    const controller = new AbortController();
    const onClose = () => {
      if (!res.writableEnded) controller.abort();
    };
    res.on("close", onClose);

    try {
      const systemMessage: Message = {
        role: "system",
        content: `أنت مساعد عربي مفيد ودقيق. أجب باللغة العربية ما لم يطلب المستخدم غير ذلك. أسلوب الرد المطلوب: ${tone}. كن واضحًا، لا تختلق معلومات، ونظّم الإجابة عند الحاجة.`,
      };
      const result = await invokeLLM({
        messages: [systemMessage, ...messages.filter(message => message.role !== "system")],
        model: model === "auto" ? undefined : model,
        max_tokens: 1400,
        signal: controller.signal,
      });
      const content = result.choices?.[0]?.message?.content;
      const reply = Array.isArray(content)
        ? content.filter(part => part.type === "text").map(part => part.text).join("\n")
        : content;
      if (!reply?.trim()) return res.status(502).json({ error: "وصل رد فارغ من نموذج الذكاء الاصطناعي." });
      return res.json({ reply });
    } catch (error) {
      if (controller.signal.aborted) return res.status(499).json({ error: "تم إيقاف التوليد." });
      console.error("[Chat] request failed", error);
      return res.status(502).json({ error: "تعذر الاتصال بالنموذج الآن. حاول مرة أخرى." });
    } finally {
      res.off("close", onClose);
    }
  });
  registerOAuthRoutes(app);
  app.use("/api/trpc", createExpressMiddleware({ router: appRouter, createContext }));
  if (process.env.NODE_ENV === "development") await setupVite(app, server);
  else serveStatic(app);

  const port = Number(process.env.PORT || "3000");
  if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error("Invalid PORT");
  server.on("error", error => { console.error("Server failed:", error.message); process.exit(1); });
  server.listen(port, "0.0.0.0", () => console.log(`Server listening on port ${port}`));
}

startServer().catch(error => { console.error(error); process.exit(1); });
