import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { listLLMModels } from "./_core/llm";
import {
  addMessage,
  createConversation,
  deleteConversation,
  getConversationById,
  getSettings,
  listConversations,
  listFavoriteTemplates,
  listMessages,
  saveSettings,
  toggleFavoriteTemplate,
  updateConversation,
  upsertUser,
} from "./db";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { protectedProcedure, publicProcedure, router } from "./_core/trpc";

export const TEMPLATES = [
  {
    id: "content-writer",
    title: "كاتب محتوى",
    category: "الكتابة",
    description: "حوّل فكرتك إلى نص واضح وجذاب يناسب جمهورك.",
    icon: "✍️",
    accent: "amber",
    fields: [{ key: "topic", label: "عن ماذا نكتب؟", placeholder: "مثال: إطلاق منتج جديد" }, { key: "audience", label: "الجمهور المستهدف", placeholder: "مثال: أصحاب المشاريع الصغيرة" }],
    prompt: "اكتب محتوى احترافيًا عن {{topic}} موجّهًا إلى {{audience}}. اجعله واضحًا، إنسانيًا، وقابلًا للنشر مع عنوان مقترح.",
  },
  {
    id: "summarizer",
    title: "ملخّص ذكي",
    category: "التلخيص",
    description: "استخرج أهم الأفكار من أي نص بسرعة ووضوح.",
    icon: "◌",
    accent: "cyan",
    fields: [{ key: "text", label: "النص المراد تلخيصه", placeholder: "الصق النص هنا..." }],
    prompt: "لخّص النص التالي بالعربية في نقاط مرتبة، ثم اذكر الخلاصة في سطر واحد:\n\n{{text}}",
  },
  {
    id: "marketing-plan",
    title: "خطة تسويقية",
    category: "التسويق",
    description: "ابنِ خطة عملية من الفكرة حتى قياس النتائج.",
    icon: "◈",
    accent: "violet",
    fields: [{ key: "product", label: "المنتج أو الخدمة", placeholder: "مثال: تطبيق إدارة مصاريف" }, { key: "goal", label: "الهدف", placeholder: "مثال: زيادة التسجيلات" }],
    prompt: "أنشئ خطة تسويقية عملية لـ {{product}} بهدف {{goal}}. اقترح الجمهور، الرسائل، القنوات، أفكار المحتوى، ومؤشرات القياس.",
  },
  {
    id: "study-coach",
    title: "مدرّب تعلّم",
    category: "التعلم",
    description: "اشرح المفاهيم الصعبة بطريقة تدريجية ومبسطة.",
    icon: "◎",
    accent: "emerald",
    fields: [{ key: "subject", label: "الموضوع", placeholder: "مثال: الانحدار الخطي" }, { key: "level", label: "مستواي الحالي", placeholder: "مثال: مبتدئ" }],
    prompt: "اشرح لي موضوع {{subject}} بما يناسب شخصًا مستواه {{level}}. استخدم مثالًا واقعيًا، ثم اختم بتمرين قصير مع الحل.",
  },
  {
    id: "code-reviewer",
    title: "مراجع كود",
    category: "البرمجة",
    description: "راجع الكود، اكتشف المشاكل، واقترح تحسينات مفهومة.",
    icon: "</>",
    accent: "blue",
    fields: [{ key: "language", label: "لغة البرمجة", placeholder: "مثال: TypeScript" }, { key: "code", label: "الكود", placeholder: "الصق الكود هنا..." }],
    prompt: "راجع كود {{language}} التالي. اذكر الأخطاء والمخاطر، ثم قدم نسخة محسنة مع شرح مختصر للتغييرات:\n\n{{code}}",
  },
  {
    id: "idea-sprint",
    title: "مولّد أفكار",
    category: "العصف الذهني",
    description: "افتح مسارات جديدة عندما تحتاج فكرة مختلفة.",
    icon: "✦",
    accent: "rose",
    fields: [{ key: "challenge", label: "التحدي أو المجال", placeholder: "مثال: أفكار لمحتوى تعليمي" }],
    prompt: "اقترح 10 أفكار مبتكرة حول {{challenge}}. اجعل كل فكرة مختلفة وقابلة للتنفيذ، وأضف سببًا يجعلها مثيرة للاهتمام.",
  },
] as const;

const templateIds: Set<string> = new Set(TEMPLATES.map(template => template.id));

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  models: router({
    list: publicProcedure.query(async () => {
      try {
        const result = await listLLMModels();
        return result.data.map(model => ({ id: model.id, label: model.id }));
      } catch {
        return [
          { id: "auto", label: "تلقائي (الأفضل للمهمة)" },
          { id: "gpt-5-mini", label: "GPT-5 Mini" },
          { id: "gemini-2.5-flash", label: "Gemini Flash" },
        ];
      }
    }),
  }),
  templates: router({
    list: publicProcedure.query(() => TEMPLATES),
    favorites: protectedProcedure.query(({ ctx }) => listFavoriteTemplates(ctx.user.id)),
    toggleFavorite: protectedProcedure
      .input(z.object({ templateId: z.string() }))
      .mutation(({ ctx, input }) => {
        if (!templateIds.has(input.templateId)) throw new TRPCError({ code: "BAD_REQUEST" });
        return toggleFavoriteTemplate(ctx.user.id, input.templateId);
      }),
  }),
  conversations: router({
    list: protectedProcedure
      .input(z.object({ search: z.string().optional() }).optional())
      .query(({ ctx, input }) => listConversations(ctx.user.id, input?.search ?? "")),
    get: protectedProcedure.input(z.object({ id: z.number() })).query(async ({ ctx, input }) => {
      const conversation = await getConversationById(input.id);
      if (!conversation || conversation.userId !== ctx.user.id) throw new TRPCError({ code: "NOT_FOUND" });
      return { conversation, messages: await listMessages(input.id) };
    }),
    create: protectedProcedure
      .input(z.object({ title: z.string().min(1).max(255), model: z.string().max(128), tone: z.string().max(64) }))
      .mutation(({ ctx, input }) => createConversation({ ...input, userId: ctx.user.id })),
    addMessage: protectedProcedure
      .input(z.object({ conversationId: z.number(), role: z.enum(["user", "assistant"]), content: z.string().min(1).max(30000) }))
      .mutation(async ({ ctx, input }) => {
        const conversation = await getConversationById(input.conversationId);
        if (!conversation || conversation.userId !== ctx.user.id) throw new TRPCError({ code: "NOT_FOUND" });
        return addMessage(input);
      }),
    update: protectedProcedure
      .input(z.object({ id: z.number(), title: z.string().min(1).max(255).optional(), model: z.string().max(128).optional(), tone: z.string().max(64).optional(), isPinned: z.number().int().min(0).max(1).optional() }))
      .mutation(async ({ ctx, input }) => {
        const conversation = await getConversationById(input.id);
        if (!conversation || conversation.userId !== ctx.user.id) throw new TRPCError({ code: "NOT_FOUND" });
        const { id, ...patch } = input;
        await updateConversation(id, patch);
        return { success: true };
      }),
    delete: protectedProcedure.input(z.object({ id: z.number() })).mutation(async ({ ctx, input }) => {
      const conversation = await getConversationById(input.id);
      if (!conversation || conversation.userId !== ctx.user.id) throw new TRPCError({ code: "NOT_FOUND" });
      await deleteConversation(input.id);
      return { success: true };
    }),
  }),
  settings: router({
    get: protectedProcedure.query(({ ctx }) => getSettings(ctx.user.id)),
    save: protectedProcedure.input(z.object({ model: z.string().max(128), tone: z.string().max(64) })).mutation(({ ctx, input }) => saveSettings(ctx.user.id, input.model, input.tone)),
  }),
});

export type AppRouter = typeof appRouter;

void upsertUser;
