import { and, desc, eq, like } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  conversations,
  InsertUser,
  messages,
  templateFavorites,
  userSettings,
  users,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) throw new Error("User openId is required for upsert");
  const db = await getDb();
  if (!db) throw new Error("Database is not available");

  const values: InsertUser = { openId: user.openId };
  const updateSet: Record<string, unknown> = {};
  const textFields = ["name", "email", "loginMethod"] as const;

  for (const field of textFields) {
    if (user[field] !== undefined) {
      values[field] = user[field] ?? null;
      updateSet[field] = user[field] ?? null;
    }
  }
  if (user.lastSignedIn !== undefined) {
    values.lastSignedIn = user.lastSignedIn;
    updateSet.lastSignedIn = user.lastSignedIn;
  }
  if (user.role !== undefined) {
    values.role = user.role;
    updateSet.role = user.role;
  } else if (user.openId === ENV.ownerOpenId) {
    values.role = "admin";
    updateSet.role = "admin";
  }
  values.lastSignedIn ??= new Date();
  if (Object.keys(updateSet).length === 0) updateSet.lastSignedIn = new Date();

  await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result[0];
}

export async function listConversations(userId: number, search = "") {
  const db = await getDb();
  if (!db) return [];
  const base = eq(conversations.userId, userId);
  const result = search.trim()
    ? await db
        .select()
        .from(conversations)
        .where(and(base, like(conversations.title, `%${search.trim()}%`)))
        .orderBy(desc(conversations.isPinned), desc(conversations.lastMessageAt))
        .limit(50)
    : await db
        .select()
        .from(conversations)
        .where(base)
        .orderBy(desc(conversations.isPinned), desc(conversations.lastMessageAt))
        .limit(50);
  return result;
}

export async function getConversationById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(conversations).where(eq(conversations.id, id)).limit(1);
  return result[0];
}

export async function listMessages(conversationId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(messages).where(eq(messages.conversationId, conversationId)).orderBy(messages.createdAt);
}

export async function createConversation(input: {
  userId: number;
  title: string;
  model: string;
  tone: string;
}) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.insert(conversations).values(input);
  return Number(result[0].insertId);
}

export async function updateConversation(
  id: number,
  patch: Partial<{ title: string; model: string; tone: string; isPinned: number }>
) {
  const db = await getDb();
  if (!db) return;
  await db.update(conversations).set(patch).where(eq(conversations.id, id));
}

export async function touchConversation(id: number) {
  const db = await getDb();
  if (!db) return;
  await db
    .update(conversations)
    .set({ lastMessageAt: new Date(), updatedAt: new Date() })
    .where(eq(conversations.id, id));
}

export async function deleteConversation(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(messages).where(eq(messages.conversationId, id));
  await db.delete(conversations).where(eq(conversations.id, id));
}

export async function addMessage(input: {
  conversationId: number;
  role: string;
  content: string;
}) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.insert(messages).values(input);
  await touchConversation(input.conversationId);
  return Number(result[0].insertId);
}

export async function listFavoriteTemplates(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(templateFavorites).where(eq(templateFavorites.userId, userId));
}

export async function toggleFavoriteTemplate(userId: number, templateId: string) {
  const db = await getDb();
  if (!db) return false;
  const current = await db
    .select()
    .from(templateFavorites)
    .where(and(eq(templateFavorites.userId, userId), eq(templateFavorites.templateId, templateId)))
    .limit(1);
  if (current.length) {
    await db.delete(templateFavorites).where(eq(templateFavorites.id, current[0].id));
    return false;
  }
  await db.insert(templateFavorites).values({ userId, templateId });
  return true;
}

export async function getSettings(userId: number) {
  const db = await getDb();
  if (!db) return { model: "auto", tone: "متوازن" };
  const result = await db.select().from(userSettings).where(eq(userSettings.userId, userId)).limit(1);
  return result[0] ?? { model: "auto", tone: "متوازن" };
}

export async function saveSettings(userId: number, model: string, tone: string) {
  const db = await getDb();
  if (!db) return;
  await db
    .insert(userSettings)
    .values({ userId, model, tone })
    .onDuplicateKeyUpdate({ set: { model, tone, updatedAt: new Date() } });
}
