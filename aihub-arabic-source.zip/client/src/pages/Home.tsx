import { useEffect, useMemo, useRef, useState } from "react";
import { toast } from "sonner";
import { Streamdown } from "streamdown";
import {
  Archive,
  ArrowUp,
  BookOpen,
  Bot,
  Check,
  ChevronDown,
  Clipboard,
  Copy,
  FileText,
  Heart,
  History,
  Menu,
  MessageSquarePlus,
  MoreHorizontal,
  Paperclip,
  Pencil,
  Pin,
  Plus,
  Search,
  Settings2,
  Sparkles,
  Square,
  Star,
  ThumbsDown,
  ThumbsUp,
  Trash2,
  X,
  Zap,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAuth } from "@/_core/hooks/useAuth";
import { startLogin } from "@/const";
import { trpc } from "@/lib/trpc";

const tones = ["متوازن", "مختصر ومباشر", "ودود وشارح", "احترافي", "إبداعي"];

type ChatMessage = {
  role: "user" | "assistant";
  content: string;
  feedback?: "up" | "down";
};

type Template = {
  id: string;
  title: string;
  category: string;
  description: string;
  icon: string;
  accent: string;
  fields: { key: string; label: string; placeholder: string }[];
  prompt: string;
};

const categoryIcons: Record<string, typeof FileText> = {
  الكتابة: FileText,
  التلخيص: Clipboard,
  التسويق: Zap,
  التعلم: BookOpen,
  البرمجة: Archive,
  "العصف الذهني": Sparkles,
};

function initials(name?: string | null) {
  if (!name) return "أ";
  return name.trim().split(/\s+/).slice(0, 2).map(part => part[0]).join("").toUpperCase();
}

function formatDate(value: Date | string | number) {
  return new Intl.DateTimeFormat("ar", { day: "numeric", month: "short" }).format(new Date(value));
}

function accentClass(accent: string) {
  return `template-accent-${accent}`;
}

export default function Home() {
  const auth = useAuth();
  const [mobileMenu, setMobileMenu] = useState(false);
  const [section, setSection] = useState<"home" | "templates" | "history">("home");
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [draft, setDraft] = useState("");
  const [busy, setBusy] = useState(false);
  const [search, setSearch] = useState("");
  const [model, setModel] = useState("auto");
  const [tone, setTone] = useState("متوازن");
  const [activeConversationId, setActiveConversationId] = useState<number | null>(null);
  const [selectedTemplate, setSelectedTemplate] = useState<Template | null>(null);
  const [templateValues, setTemplateValues] = useState<Record<string, string>>({});
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);
  const [feedbacks, setFeedbacks] = useState<Record<number, "up" | "down">>({});
  const abortRef = useRef<AbortController | null>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const templatesQuery = trpc.templates.list.useQuery();
  const modelsQuery = trpc.models.list.useQuery();
  const conversationsQuery = trpc.conversations.list.useQuery(
    { search },
    { enabled: auth.isAuthenticated, retry: false }
  );
  const settingsQuery = trpc.settings.get.useQuery(undefined, { enabled: auth.isAuthenticated, retry: false });
  const favoritesQuery = trpc.templates.favorites.useQuery(undefined, { enabled: auth.isAuthenticated, retry: false });
  const conversationQuery = trpc.conversations.get.useQuery(
    { id: activeConversationId ?? 0 },
    { enabled: Boolean(auth.isAuthenticated && activeConversationId), retry: false }
  );
  const utils = trpc.useUtils();
  const createConversation = trpc.conversations.create.useMutation();
  const addMessage = trpc.conversations.addMessage.useMutation();
  const toggleFavorite = trpc.templates.toggleFavorite.useMutation({
    onSuccess: () => utils.templates.favorites.invalidate(),
  });
  const saveSettings = trpc.settings.save.useMutation();
  const updateConversation = trpc.conversations.update.useMutation({
    onSuccess: () => utils.conversations.list.invalidate(),
  });
  const deleteConversation = trpc.conversations.delete.useMutation({
    onSuccess: () => utils.conversations.list.invalidate(),
  });

  const templates = (templatesQuery.data ?? []) as unknown as Template[];
  const favoriteIds = useMemo(
    () => new Set((favoritesQuery.data ?? []).map(item => item.templateId)),
    [favoritesQuery.data]
  );

  useEffect(() => {
    if (settingsQuery.data) {
      setModel(settingsQuery.data.model);
      setTone(settingsQuery.data.tone);
    }
  }, [settingsQuery.data]);

  useEffect(() => {
    const data = conversationQuery.data;
    if (!data || !activeConversationId) return;
    setMessages(data.messages.map(message => ({ role: message.role as ChatMessage["role"], content: message.content })));
    setModel(data.conversation.model);
    setTone(data.conversation.tone);
  }, [conversationQuery.data, activeConversationId]);

  useEffect(() => {
    textareaRef.current?.focus();
  }, []);

  const currentCategory = section === "templates" ? "القوالب" : section === "history" ? "المحادثات" : "الرئيسية";

  const chooseConversation = (id: number) => {
    setActiveConversationId(id);
    setSection("home");
    setMobileMenu(false);
  };

  const newConversation = () => {
    abortRef.current?.abort();
    setActiveConversationId(null);
    setMessages([]);
    setDraft("");
    setBusy(false);
    setSection("home");
    setMobileMenu(false);
    textareaRef.current?.focus();
  };

  const saveConversationMessages = async (conversationId: number, userText: string, assistantText?: string) => {
    try {
      await addMessage.mutateAsync({ conversationId, role: "user", content: userText });
      if (assistantText) await addMessage.mutateAsync({ conversationId, role: "assistant", content: assistantText });
      await utils.conversations.list.invalidate();
    } catch {
      toast.error("تعذر حفظ المحادثة، لكن يمكنك متابعة الدردشة.");
    }
  };

  const requestReply = async (conversationMessages: ChatMessage[], userText?: string) => {
    const controller = new AbortController();
    abortRef.current = controller;
    setBusy(true);
    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        signal: controller.signal,
        body: JSON.stringify({
          model,
          tone,
          messages: conversationMessages.map(message => ({ role: message.role, content: message.content })),
        }),
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(data.error || "تعذر الحصول على الرد");
      const reply = String(data.reply || "");
      setMessages(previous => [...previous, { role: "assistant", content: reply }]);

      if (auth.isAuthenticated && userText) {
        let conversationId = activeConversationId;
        if (!conversationId) {
          const created = await createConversation.mutateAsync({ title: userText.slice(0, 54), model, tone });
          conversationId = Number(created);
          setActiveConversationId(conversationId);
        }
        await saveConversationMessages(conversationId, userText, reply);
      } else if (auth.isAuthenticated && activeConversationId && !userText) {
        await addMessage.mutateAsync({ conversationId: activeConversationId, role: "assistant", content: reply });
      }
      return reply;
    } catch (error) {
      if (controller.signal.aborted) {
        toast.message("تم إيقاف التوليد");
      } else {
        toast.error(error instanceof Error ? error.message : "تعذر الاتصال بالمساعد");
      }
      return null;
    } finally {
      if (abortRef.current === controller) abortRef.current = null;
      setBusy(false);
    }
  };

  const sendMessage = async (event?: React.FormEvent) => {
    event?.preventDefault();
    const text = draft.trim();
    if (!text || busy) return;
    const nextMessages = [...messages, { role: "user" as const, content: text }];
    setMessages(nextMessages);
    setDraft("");
    await requestReply(nextMessages, text);
  };

  const regenerate = async () => {
    if (busy) return;
    const lastUser = [...messages].reverse().find(message => message.role === "user");
    if (!lastUser) return;
    const withoutLastAssistant = messages[messages.length - 1]?.role === "assistant" ? messages.slice(0, -1) : messages;
    setMessages(withoutLastAssistant);
    await requestReply(withoutLastAssistant);
  };

  const stopGeneration = () => abortRef.current?.abort();

  const applyTemplate = () => {
    if (!selectedTemplate) return;
    const prompt = selectedTemplate.prompt.replace(/\{\{(\w+)\}\}/g, (_, key: string) => templateValues[key]?.trim() || `[${key}]`);
    setDraft(prompt);
    setSelectedTemplate(null);
    setSection("home");
    setTimeout(() => textareaRef.current?.focus(), 50);
  };

  const copyMessage = async (content: string, index: number) => {
    await navigator.clipboard.writeText(content);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 1500);
  };

  const startTemplate = (template: Template) => {
    setTemplateValues(Object.fromEntries(template.fields.map(field => [field.key, ""])));
    setSelectedTemplate(template);
  };

  const handleLogin = () => {
    try {
      startLogin();
    } catch {
      toast.error("تسجيل الدخول غير مهيّأ في هذه المعاينة بعد.");
    }
  };

  const renderTemplateCard = (template: Template, compact = false) => {
    const Icon = categoryIcons[template.category] ?? Sparkles;
    return (
      <button
        key={template.id}
        onClick={() => startTemplate(template)}
        className={`template-card ${accentClass(template.accent)} ${compact ? "template-card-compact" : ""}`}
      >
        <span className="template-icon"><Icon size={compact ? 17 : 20} /></span>
        <span className="template-card-copy">
          <span className="template-card-topline"><strong>{template.title}</strong><span className="template-category">{template.category}</span></span>
          <span>{template.description}</span>
        </span>
        <span className="template-arrow">←</span>
      </button>
    );
  };

  return (
    <div className="app-shell" dir="rtl">
      <aside className={`sidebar ${mobileMenu ? "sidebar-open" : ""}`}>
        <div className="brand-lockup">
          <div className="brand-mark"><Sparkles size={19} /></div>
          <div><strong>مساحة <span>AI</span></strong><small>ذكاء يعمل معك</small></div>
        </div>
        <button className="sidebar-close" onClick={() => setMobileMenu(false)} aria-label="إغلاق القائمة"><X size={18} /></button>
        <Button className="new-chat-button" onClick={newConversation}><Plus size={17} /> محادثة جديدة</Button>
        <nav className="main-nav" aria-label="التنقل الرئيسي">
          <button className={section === "home" ? "nav-item active" : "nav-item"} onClick={() => { setSection("home"); setMobileMenu(false); }}><Zap size={17} /> الرئيسية</button>
          <button className={section === "templates" ? "nav-item active" : "nav-item"} onClick={() => { setSection("templates"); setMobileMenu(false); }}><Sparkles size={17} /> مكتبة القوالب <span className="nav-count">{templates.length}</span></button>
          <button className={section === "history" ? "nav-item active" : "nav-item"} onClick={() => { setSection("history"); setMobileMenu(false); }}><History size={17} /> سجل المحادثات</button>
        </nav>
        <div className="sidebar-section-title"><span>الأخيرة</span><button onClick={() => setSection("history")}>عرض الكل</button></div>
        <div className="conversation-list">
          {!auth.isAuthenticated ? (
            <button className="login-hint" onClick={handleLogin}><Archive size={16} /><span>سجّل دخولك لحفظ محادثاتك</span></button>
          ) : conversationsQuery.isLoading ? <div className="skeleton-list"><i /><i /><i /></div> : conversationsQuery.data?.slice(0, 5).map(conversation => (
            <div key={conversation.id} className={`conversation-row ${activeConversationId === conversation.id ? "selected" : ""}`}>
              <button onClick={() => chooseConversation(conversation.id)} className="conversation-button"><MessageSquarePlus size={15} /><span>{conversation.title}</span></button>
              <button className="conversation-more" onClick={() => updateConversation.mutate({ id: conversation.id, isPinned: conversation.isPinned ? 0 : 1 })} title={conversation.isPinned ? "إلغاء التثبيت" : "تثبيت"}>{conversation.isPinned ? <Pin size={13} fill="currentColor" /> : <MoreHorizontal size={15} />}</button>
            </div>
          ))}
        </div>
        <div className="sidebar-bottom">
          <div className="preference-row"><Settings2 size={15} /><span>نبرة الرد</span><select value={tone} onChange={event => { setTone(event.target.value); if (auth.isAuthenticated) saveSettings.mutate({ model, tone: event.target.value }); }}><option>{tones[0]}</option>{tones.slice(1).map(item => <option key={item}>{item}</option>)}</select></div>
          <div className="user-card">
            <div className="user-avatar">{auth.isAuthenticated ? initials(auth.user?.name) : <Bot size={17} />}</div>
            <div className="user-meta"><strong>{auth.isAuthenticated ? auth.user?.name || "مستخدم مساحة AI" : "زائر"}</strong><span>{auth.isAuthenticated ? "حساب شخصي" : "دردشة محلية"}</span></div>
            {auth.isAuthenticated ? <button className="user-action" onClick={() => auth.logout()} title="تسجيل الخروج"><MoreHorizontal size={18} /></button> : <button className="login-button" onClick={handleLogin}>دخول</button>}
          </div>
        </div>
      </aside>

      <main className="main-panel">
        <header className="topbar">
          <button className="mobile-menu-button" onClick={() => setMobileMenu(true)} aria-label="فتح القائمة"><Menu size={20} /></button>
          <div className="breadcrumb"><span>مساحة AI</span><span className="breadcrumb-separator">/</span><strong>{currentCategory}</strong></div>
          <div className="topbar-actions"><div className="status-dot"><i /> النماذج تعمل</div><button className="topbar-icon" title="الإعدادات"><Settings2 size={18} /></button></div>
        </header>

        <div className="content-scroll">
          {section === "templates" ? (
            <section className="section-page">
              <div className="page-heading"><div><span className="eyebrow">مسارات جاهزة</span><h1>ابدأ من قالب، ثم اجعله لك</h1><p>اختر نقطة انطلاق مصممة لمهمتك، املأ التفاصيل، واترك الباقي للمساعد.</p></div><div className="heading-badge"><Sparkles size={15} /> {templates.length} قوالب عملية</div></div>
              <div className="category-filter"><button className="filter-chip active">الكل</button>{["الكتابة", "التسويق", "التعلم", "البرمجة"].map(category => <button key={category} className="filter-chip">{category}</button>)}</div>
              <div className="templates-grid">{templates.map(template => renderTemplateCard(template))}</div>
            </section>
          ) : section === "history" ? (
            <section className="section-page">
              <div className="page-heading"><div><span className="eyebrow">ذاكرتك العملية</span><h1>سجل المحادثات</h1><p>كل فكرة بدأت هنا تبقى قريبة منك، مرتبة وقابلة للعودة.</p></div><Button onClick={newConversation}><Plus size={16} /> محادثة جديدة</Button></div>
              {auth.isAuthenticated ? <div className="history-panel"><div className="history-search"><Search size={17} /><input value={search} onChange={event => setSearch(event.target.value)} placeholder="ابحث في محادثاتك..." /></div>{conversationsQuery.data?.length ? conversationsQuery.data.map(conversation => <div key={conversation.id} className="history-row"><div className="history-row-icon"><MessageSquarePlus size={18} /></div><button className="history-title" onClick={() => chooseConversation(conversation.id)}><strong>{conversation.title}</strong><span>{formatDate(conversation.lastMessageAt)} · {conversation.tone}</span></button><button className="icon-button" onClick={() => updateConversation.mutate({ id: conversation.id, isPinned: conversation.isPinned ? 0 : 1 })}>{conversation.isPinned ? <Pin size={16} fill="currentColor" /> : <Pin size={16} />}</button><button className="icon-button danger" onClick={() => { if (confirm("حذف هذه المحادثة؟")) deleteConversation.mutate({ id: conversation.id }); }}><Trash2 size={16} /></button></div>) : <div className="empty-state"><History size={34} /><h3>لا توجد محادثات محفوظة بعد</h3><p>ابدأ محادثة جديدة، وستجدها هنا تلقائيًا.</p><Button onClick={newConversation}>ابدأ الآن</Button></div>}</div> : <div className="login-card"><div className="login-card-icon"><Archive size={22} /></div><h3>احفظ أفكارك وارجع لها في أي وقت</h3><p>سجّل دخولك بحساب Manus لتفعيل سجل المحادثات والمفضلة بشكل خاص.</p><Button onClick={handleLogin}>تسجيل الدخول</Button></div>}
            </section>
          ) : (
            <section className="home-section">
              {messages.length === 0 ? <>
                <div className="hero-copy"><div className="hero-kicker"><span><Sparkles size={14} /> مساحة عمل ذكية</span></div><h1>ماذا ننجز<br /><em>اليوم؟</em></h1><p>اكتب فكرتك كما هي. سأساعدك على تحويلها إلى نتيجة واضحة، بالعربية التي تليق بها.</p></div>
                <form className="composer hero-composer" onSubmit={sendMessage}><textarea ref={textareaRef} value={draft} onChange={event => setDraft(event.target.value)} onKeyDown={event => { if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); void sendMessage(); } }} placeholder="اسأل، اكتب، أو ابدأ بفكرة..." rows={3} /><div className="composer-footer"><div className="composer-tools"><button type="button" title="إرفاق ملف"><Paperclip size={17} /></button><select value={model} onChange={event => { setModel(event.target.value); if (auth.isAuthenticated) saveSettings.mutate({ model: event.target.value, tone }); }}>{(modelsQuery.data ?? [{ id: "auto", label: "تلقائي" }]).map(item => <option key={item.id} value={item.id}>{item.label}</option>)}</select></div><Button type="submit" size="icon" disabled={!draft.trim() || busy} className="send-button"><ArrowUp size={19} /></Button></div></form>
                <div className="quick-start"><div className="quick-start-head"><span>انطلاقة سريعة</span><button onClick={() => setSection("templates")}>كل القوالب <span>←</span></button></div><div className="quick-grid">{templates.slice(0, 4).map(template => renderTemplateCard(template, true))}</div></div>
                <div className="trust-row"><span><Check size={14} /> عربي أولًا</span><span><Check size={14} /> خصوصية محادثاتك</span><span><Check size={14} /> قابل للتخصيص</span></div>
              </> : <div className="chat-layout"><div className="chat-header"><div><span className="eyebrow">محادثة نشطة</span><h1>{activeConversationId ? conversationsQuery.data?.find(item => item.id === activeConversationId)?.title || "محادثة جديدة" : "محادثة جديدة"}</h1></div><div className="chat-header-actions"><select value={model} onChange={event => setModel(event.target.value)}>{(modelsQuery.data ?? [{ id: "auto", label: "تلقائي" }]).map(item => <option key={item.id} value={item.id}>{item.label}</option>)}</select><button className="icon-button"><MoreHorizontal size={18} /></button></div></div><div className="messages-list">{messages.map((message, index) => <div key={`${index}-${message.role}`} className={`message-row ${message.role === "user" ? "message-user" : "message-assistant"}`}><div className={`message-avatar ${message.role === "assistant" ? "assistant-avatar" : "user-avatar-small"}`}>{message.role === "assistant" ? <Sparkles size={15} /> : initials(auth.user?.name)}</div><div className="message-content"><div className="message-meta"><strong>{message.role === "assistant" ? "مساحة AI" : "أنت"}</strong><span>{message.role === "assistant" ? "مساعدك الذكي" : "الآن"}</span></div><div className="message-bubble">{message.role === "assistant" ? <Streamdown>{message.content}</Streamdown> : message.content}</div>{message.role === "assistant" && <div className="message-actions"><button onClick={() => copyMessage(message.content, index)}>{copiedIndex === index ? <Check size={14} /> : <Copy size={14} />} {copiedIndex === index ? "نُسخ" : "نسخ"}</button><button onClick={() => setFeedbacks(previous => ({ ...previous, [index]: "up" }))} className={feedbacks[index] === "up" ? "chosen" : ""}><ThumbsUp size={14} /></button><button onClick={() => setFeedbacks(previous => ({ ...previous, [index]: "down" }))} className={feedbacks[index] === "down" ? "chosen" : ""}><ThumbsDown size={14} /></button>{index === messages.length - 1 && <button onClick={() => void regenerate()}><Zap size={14} /> إعادة التوليد</button>}</div>}</div></div>)}{busy && <div className="message-row message-assistant"><div className="message-avatar assistant-avatar"><Sparkles size={15} /></div><div className="message-content"><div className="message-meta"><strong>مساحة AI</strong><span>يكتب الآن</span></div><div className="message-bubble typing"><i /><i /><i /></div></div></div>}</div><form className="composer chat-composer" onSubmit={sendMessage}><textarea ref={textareaRef} value={draft} onChange={event => setDraft(event.target.value)} onKeyDown={event => { if (event.key === "Enter" && !event.shiftKey) { event.preventDefault(); void sendMessage(); } }} placeholder="اكتب رسالتك التالية..." rows={2} /><div className="composer-footer"><div className="composer-tools"><button type="button"><Paperclip size={17} /></button><span className="composer-note">Shift + Enter لسطر جديد</span></div>{busy ? <Button type="button" size="icon" variant="outline" onClick={stopGeneration} className="stop-button"><Square size={15} fill="currentColor" /></Button> : <Button type="submit" size="icon" disabled={!draft.trim()} className="send-button"><ArrowUp size={19} /></Button>}</div></form></div>}
            </section>
          )}
        </div>
      </main>

      {selectedTemplate && <div className="modal-backdrop" onClick={() => setSelectedTemplate(null)}><div className="template-modal" onClick={event => event.stopPropagation()}><div className="modal-top"><div className={`template-icon ${accentClass(selectedTemplate.accent)}`}><Sparkles size={19} /></div><button className="icon-button" onClick={() => setSelectedTemplate(null)}><X size={18} /></button></div><span className="eyebrow">قالب {selectedTemplate.category}</span><h2>{selectedTemplate.title}</h2><p>{selectedTemplate.description}</p><div className="template-fields">{selectedTemplate.fields.map(field => <label key={field.key}>{field.label}<textarea value={templateValues[field.key] ?? ""} onChange={event => setTemplateValues(previous => ({ ...previous, [field.key]: event.target.value }))} placeholder={field.placeholder} rows={field.key === "text" || field.key === "code" ? 5 : 2} /></label>)}</div><Button onClick={applyTemplate} className="modal-cta"><Sparkles size={16} /> جهّز المحادثة</Button></div></div>}
    </div>
  );
}
